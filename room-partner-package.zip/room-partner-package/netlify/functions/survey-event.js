exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' }, body: '' };
  }
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };

  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceKey) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY environment variables.' }) };
  }

  let data;
  try { data = JSON.parse(event.body || '{}'); }
  catch { return { statusCode: 400, body: 'Invalid JSON' }; }

  if (!data.session_id || !data.event_type) return { statusCode: 400, body: 'session_id and event_type are required' };
  const allowed = new Set(['survey_started', 'question_viewed', 'answer_changed', 'survey_click', 'survey_completed', 'page_exit']);
  if (!allowed.has(data.event_type)) return { statusCode: 400, body: 'Unsupported event_type' };

  const row = {
    session_id: String(data.session_id).slice(0, 160),
    event_type: data.event_type,
    step: data.step ? String(data.step).slice(0, 80) : null,
    step_index: Number.isInteger(data.step_index) ? data.step_index : null,
    answers: data.answers && typeof data.answers === 'object' ? data.answers : {},
    status: ['in_progress', 'completed', 'abandoned'].includes(data.status) ? data.status : (data.event_type === 'survey_completed' ? 'completed' : 'in_progress'),
    extra: data.extra && typeof data.extra === 'object' ? data.extra : {},
    occurred_at: data.occurred_at || new Date().toISOString()
  };

  try {
    const response = await fetch(`${supabaseUrl.replace(/\/$/, '')}/rest/v1/survey_events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': serviceKey,
        'Authorization': `Bearer ${serviceKey}`,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify(row)
    });
    if (!response.ok) {
      const detail = await response.text();
      console.error('Supabase insert failed:', response.status, detail);
      return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Could not store survey event.' }) };
    }
    return { statusCode: 204, body: '' };
  } catch (error) {
    console.error('Survey event error:', error);
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'Unexpected server error.' }) };
  }
};

# room. — Partner questionnaire

This package preserves the original prototype and adds an in-app partner questionnaire, event logging, and a Netlify Function that writes event snapshots to Supabase.

## Deploy
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Deploy this folder to Netlify (the `index.html` file is at the project root).
4. In Netlify → Site configuration → Environment variables, add:
   - `SUPABASE_URL` — your Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY` — the service-role key for that project. Keep it server-side; never put it in `index.html`.
5. Redeploy the site.

The front end sends events for survey start, question views, each answer change, completion, and page exit. Each row contains a snapshot of answers and the current question. `page_exit` rows use status `abandoned`; closing a tab/browser abruptly may prevent a browser from sending that final event, but prior answer snapshots are already stored as the user goes.

## Important question wording
The original HTML did not include the Google Doc wording for Q3 or Q4. Those two labels are explicitly marked in the UI as placeholders; replace `SURVEY_LABELS.q3` and `SURVEY_LABELS.q4` in `index.html` with the exact wording from your document. Q4 is currently a 0–100 slider placeholder.

## Inspect results
In Supabase Table Editor, open `survey_events`. Each event is a row; group by `session_id` to reconstruct the path and use the latest row per session for the latest answers/status. A completion is `event_type = survey_completed`; exits are `event_type = page_exit` with status `abandoned`.

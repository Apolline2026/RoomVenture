create table if not exists public.survey_events (
  id bigint generated always as identity primary key,
  session_id text not null,
  event_type text not null,
  step text,
  step_index integer,
  answers jsonb not null default '{}'::jsonb,
  status text not null default 'in_progress' check (status in ('in_progress','completed','abandoned')),
  extra jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists survey_events_session_id_idx on public.survey_events(session_id);
create index if not exists survey_events_created_at_idx on public.survey_events(created_at desc);
-- Do not expose this table to unauthenticated clients. Writes go through the Netlify Function.
alter table public.survey_events enable row level security;
